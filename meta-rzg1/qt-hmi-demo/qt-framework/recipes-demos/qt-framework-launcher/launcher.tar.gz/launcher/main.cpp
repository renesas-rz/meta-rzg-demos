#include "app_launcher.h"
#include <QDir>
#include <QGuiApplication>
#include <QQmlEngine>
#include <QQmlFileSelector>
#include <QQuickView>

int main(int argc, char* argv[]) 
{
    QGuiApplication guiApp(argc,argv);

    guiApp.setApplicationName(QFileInfo(guiApp.applicationFilePath()).baseName());

    qmlRegisterType<App_Launcher>("_Launcher", 1 , 0, "App_Launcher");

    QQuickView view;
    if (qgetenv("QT_QUICK_CORE_PROFILE").toInt()) {
        QSurfaceFormat f = view.format();
        f.setProfile(QSurfaceFormat::CoreProfile);
        f.setVersion(4, 4);
        view.setFormat(f);
    }

    view.connect(view.engine(), SIGNAL(quit()), &guiApp, SLOT(quit()));
    new QQmlFileSelector(view.engine(), &view);

    view.setSource(QUrl("qrc:///launcher/launcher.qml")); 
    view.setResizeMode(QQuickView::SizeRootObjectToView);

    view.show();
    return guiApp.exec();
}

