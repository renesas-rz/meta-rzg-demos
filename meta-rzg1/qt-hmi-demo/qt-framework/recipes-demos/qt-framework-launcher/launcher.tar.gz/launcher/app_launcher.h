#ifndef APP_LAUNCHER_H
#define APP_LAUNCHER_H

#include <QObject>
#include <QProcess>

class App_Launcher: public QObject
{
	Q_OBJECT

public:
    explicit App_Launcher(QObject *parent = 0);
    ~App_Launcher();

	Q_INVOKABLE void launch(const QString &program);

protected:
	QProcess* m_process;
};

#endif //APP_LAUNCHER_H
