#include "app_launcher.h"
#include <QProcess>
#include <QDebug>

App_Launcher::App_Launcher(QObject *parent) :
	QObject(parent),
	m_process(new QProcess(this))
{
}

void App_Launcher::launch(const QString &program)
{
    m_process->startDetached(program);
}

App_Launcher::~App_Launcher() {
}
