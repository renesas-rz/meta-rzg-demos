#ifndef __SOCAUTH_H__
#define __SOCAUTH_H__

#define TRUE 		1
#define FALSE		0

/* Device type */
enum ren_rzg_type {
	UNKNOWN=0,
	RZG1E=0x4C,
	RZG1M=0x47,
	RZG1N=0x4B,
	RZG1H=0x45,

};

struct ren_soc_id {
	int isRzg;

	/* if ren_ isRzg_failed then rzg_type is unknown */
	enum ren_rzg_type   type;
};

/**
 * @name   soc_auth_dev_open
 *
 * This API open the uio device.
 *
 * @param [in] device_name  Device name of device defined with /dev/uioX.
 *
 * @retval int FILE .
 		FILE  < 0 : Open file failed.
 * Example Usage:
 * @code
     	int fd;
     	fd = soc_auth_dev_open("uio_prr");
     	if (!fd)
     		printf("Failed to open device\n");
 * @endcode
 */
 int soc_auth_dev_open(const char* device_name);

/**
 * @name   soc_auth_dev_identify
 *
 * This API identify the device.
 *
 * @param [in] 	fd	Device file description. 
 * @param [out]	id_p    Pointer to struct ren_soc_id.
 *
 * @retval int ret .
 		ret < 0 : Failed to authenticate.
 * Example Usage:
 * @code
     	int ret;
	struct rensoc_id ID;

     	ret = soc_auth_dev_identify(fd, &ID);
     	if (!ret)
     		printf("Failed to authenticate device\n");

 * @endcode
 */
int soc_auth_dev_identify(int fd, struct ren_soc_id* id_p);

/**
 * @name   soc_auth_dev_close
 *
 * This API close the uio device.
 *
 * @param [in] file_desc  Device file description.
 *
 * Example Usage:
 * @code
		int fd;
 		fd = soc_auth_dev_open("uio_prr");

		................................

 		 soc_auth_dev_close(fd);
 * @endcode
 */
void soc_auth_dev_close(int file_desc);

#endif 
