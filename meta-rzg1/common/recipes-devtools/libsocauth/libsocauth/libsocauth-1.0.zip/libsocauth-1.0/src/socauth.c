#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include "include/socauth.h"


/*---------------------Definition--------------------*/
#define		ID_BIT_MASK	0x00007F00	/* bit 14_8 */
#define		ID_BIT_SHIFT	8
#define		PRR_POS		17		/* = 0x44 / sizeof(unsigned int) */
#define 	MEM_SIZE 	0x1000

/*
 * Read name from /sys/class/uio/uioX/name
 */
static int _uio_line_from_file(char *filename, char *linebuf)
{
	char *s;
	int i;

	memset((void*)linebuf, 0, 100);
	FILE* file = fopen(filename,"r");
	if (!file) return -1;
	s = fgets(linebuf,100,file);
	if (!s) return -2;
	for (i=0; (*s)&&(i<100); i++) {
		if (*s == '\n') *s = 0;
		s++; 
	}

	return 0;
}

/*
 * Compare UIO device name with name of device information in 
 * sys/class/uio
 */
static int  cmp_dev_name(const char* sys_dev, char* uio_name)
{
	char linebuf[100];
	char filename[100];

	/* Read & compare sys_dev */
	snprintf(filename, sizeof(filename), "/sys/class/uio/%s/name", sys_dev);
	if (_uio_line_from_file(filename, linebuf)){
		return 0;
	}

	if (strncmp(linebuf, uio_name, 100)) {
		return 0;
	}

#ifdef _DEBUG_ 
		printf("Name: %s \n", uio_name);
#endif
	 return 1;
}


/*  Scan all UIO device data in /sys/class/uio
 *  to find uio devcie corresponding with input name.
 *
 *  Usage:
 *  For example, with uio device name "uio_prr", then 
 *
 *  find_dev_by_name("uio_prr", &devname);
 *  -> devname=/dev/uio0 
 * */
static int  find_dev_by_name(const char* uio_name, char* dev_name)
{
	struct dirent **namelist;
	int n;
	char linebuf[100];
	char filename[100];
	int ret;

	n = scandir("/sys/class/uio", &namelist, 0, alphasort);
	if (n < 0)
		return 0;

	/* Device is singleton*/
  	 while (n--) {
		/* Read & compare uio_name */
		ret = cmp_dev_name(namelist[n]->d_name, uio_name);
		if(ret) {
			strncat(dev_name, namelist[n]->d_name, strlen(namelist[n]->d_name));
		} 

		free(namelist[n]);
	 } 
	 free(namelist);

	 return 1;
}


/**
 * @name   soc_auth_dev_open
 * This API open the uio device.
 */

int soc_auth_dev_open(const char* device_name)
 {

 	int fd;
	char devname[100]="/dev/";

	/* There may have many uio device in /dev/,which is dev/uio0, /dev/uio1...,
	 * So first, scanning all uioX.name in /sys/class/uio, name="uio_prr" to find 
	 * the value X
	 * devname has the format: /dev/uioX */
	find_dev_by_name(device_name, devname);
#ifdef _DEBUG_ 
	printf("At least, devname is %s \n", devname);
#endif
 	/* Open /dev/uioX */
     	if ((fd = open(devname, O_RDONLY | O_SYNC)) == -1) {
		printf("Opening UIO device is failed !!! \n");
		return -1;
     	} else  {
	       	return fd;
	}

     return 1;
 }



/**
 * @name   soc_auth_dev_identify
 * This API identify the device.
 */
 int soc_auth_dev_identify(int fd, struct ren_soc_id* id_p)
 {
  	unsigned long *map_base;
	unsigned long readval;

      map_base = mmap(NULL, MEM_SIZE, PROT_READ, MAP_SHARED, fd, 0);
      if (map_base == MAP_FAILED) {
		printf("Mapping device memory is failed !!! \n");
		close(fd);
          return -1;
       }
      
	readval = *(map_base  + 17);
#ifdef _DEBUG_
	printf("Address : 0x%lx, value: 0x%lx .\n",(map_base+17), readval);
#endif
 	/* Parse and map type */
	id_p->type  = (readval  & ID_BIT_MASK) >> ID_BIT_SHIFT;	
	if ((id_p->type == RZG1E) 
	   || (id_p->type == RZG1M)
	   || (id_p->type == RZG1H)
	   || (id_p->type == RZG1N)) {
		id_p->isRzg = TRUE;
#ifdef _DEBUG_
		printf("Device type value:  0x%x . \n", id_p->type);
#endif
	} else {
			id_p->isRzg = FALSE;
	}
	
	/* unmap */
	if (munmap(map_base, MEM_SIZE) == -1) {
		 return -1;
 	 }

	return 1;
 }

 
/**
 * @name   soc_auth_dev_close
 * This API close the uio device.
 */
void soc_auth_dev_close(int file_desc)
{
  	/* Close file */ 

#ifdef _DEBUG_
	printf("Close file !!! \n");
#endif

	close(file_desc);
	return;
}

