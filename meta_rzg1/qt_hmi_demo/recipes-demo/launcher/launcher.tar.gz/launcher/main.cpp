#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QtQml>

#include "launch.h"


/****************************************/





int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;

    ScriptLauncher launcher;
    QQmlContext *context = engine.rootContext();
    context->setContextProperty("scriptLauncher", &launcher);
    qmlRegisterType<Actor>("Executive", 1, 0, "Actor");
    engine.load(QUrl(QStringLiteral("main.qml")));

    return app.exec();
}
