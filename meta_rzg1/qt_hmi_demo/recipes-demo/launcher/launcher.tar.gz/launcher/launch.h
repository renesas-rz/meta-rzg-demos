#ifndef LAUNCH_H
#define LAUNCH_H



#include <QObject>
#include <QProcess>


/*
 *  process wraper
 */
class CSelfDestroy: public QProcess{

    Q_OBJECT

private slots:
    void DelProcSlot(){
        emit DeleteProcessSignal(this);
    }

signals:
    void DeleteProcessSignal(CSelfDestroy* p);

public:
    virtual ~CSelfDestroy(){
        if (this->parent()){
            disconnect(this, SIGNAL( DeleteProcessSignal(CSelfDestroy*) ), this->parent(), SLOT(DelProcSlot(CSelfDestroy*)));
        }
        disconnect( this, SIGNAL( finished(int))  , this, SLOT( DelProcSlot() ) );
    }
    explicit CSelfDestroy(QObject *con = 0, QObject *parent = 0): QProcess(parent), actor(con){
        connect( this, SIGNAL( finished(int))  , this, SLOT( DelProcSlot() ) );
        if (parent){
            connect(this, SIGNAL( DeleteProcessSignal(CSelfDestroy*) ), parent, SLOT(DelProcSlot(CSelfDestroy*)));
        }

    }
public:
    QObject *actor;
};





class Actor : public QObject
{

    Q_OBJECT
public:
    explicit Actor(QObject *parent = 0):
        QObject(parent)
    {
    }
    virtual ~Actor()
    {
    }
signals:
    void action();
public slots:
    void onaction(){emit action();}
};







/*
 *  Launcher
 */
class ScriptLauncher : public QObject
{

    Q_OBJECT

public:
    explicit ScriptLauncher(QObject *parent = 0):
        QObject(parent)
    {

    }
    virtual ~ScriptLauncher()
    {
    }
    Q_INVOKABLE void launchScript(QString name, QString args, QObject* a=0)
    {
        CSelfDestroy* p = new CSelfDestroy(a,this);
        QStringList listArgs;
        listArgs=args.split(" ");
        if (p){
            if (a){
                connect(this, SIGNAL(appKill()), a, SLOT(onaction()) );
            }
            processArray.push_back(p);
            p->start(name, listArgs);
        }

    }

    Q_INVOKABLE int count() const{
        return (processArray.size());
    }

public slots:
    void DelProcSlot(CSelfDestroy* p){
        emit appKill();
        int i = processArray.indexOf(p);
        QProcessList::Iterator it = processArray.begin();
        if (i != -1){
            if (p->actor){
                disconnect(this, SIGNAL(appKill()), p->actor, SLOT(onaction()) );
            }
            processArray.erase(it + i);
            delete p;
        }
    }
signals:
    void appKill();
private:
    /* types */

    typedef QList<CSelfDestroy*> QProcessList;


    /**/
    QProcessList processArray;

};




#endif // LAUNCH_H
