/****************************************************************************
**
** Copyright (C) 2014 Digia Plc and/or its subsidiary(-ies).
** Contact: http://www.qt-project.org/legal
**
** This file is part of the Qt Mobility Components.
**
** $QT_BEGIN_LICENSE:LGPL21$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and Digia. For licensing terms and
** conditions see http://qt.digia.com/licensing. For further information
** use the contact form at http://qt.digia.com/contact-us.
**
** GNU Lesser General Public License Usage
** Alternatively, this file may be used under the terms of the GNU Lesser
** General Public License version 2.1 or version 3 as published by the Free
** Software Foundation and appearing in the file LICENSE.LGPLv21 and
** LICENSE.LGPLv3 included in the packaging of this file. Please review the
** following information to ensure the GNU Lesser General Public License
** requirements will be met: https://www.gnu.org/licenses/lgpl.html and
** http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html.
**
** In addition, as a special exception, Digia gives you certain additional
** rights. These rights are described in the Digia Qt LGPL Exception
** version 1.1, included in the file LGPL_EXCEPTION.txt in this package.
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include <QtCore/QStandardPaths>
#include <QtCore/QString>
#include <QtCore/QStringList>
#include <QtQml/QQmlContext>
#include <QtQml/QQmlEngine>
#include <QtGui/QGuiApplication>
#include <QtQuick/QQuickItem>
#include <QtQuick/QQuickView>

#include <QtCore/QTimer>
#include <signal.h>
#include "memory.h"
#include "fileio.h"

#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <net/if.h>
#include <arpa/inet.h>

static const QString DefaultFileName1 = "";
static const QString DefaultFileName2 = "";
void exit_properly (int);
QGuiApplication *p_app;

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    p_app = &app;	/* For calling quit in signal handler */

    QQuickView viewer;
    viewer.setSource(QUrl("qrc:///qml/simpleplayer/main.qml"));
    viewer.rootContext()->setContextProperty("Get_MEM", new Get_MEM);
    QObject::connect(viewer.engine(), SIGNAL(quit()), &viewer, SLOT(close()));

    FileIO fileIO;
    viewer.rootContext()->setContextProperty("fileio", &fileIO);

	// Get Wireless LAN IP and set to main.qml propery.
	// The Wireless LAN must be set up correctly before running
	{
		int fd;
		struct ifreq ifr;
		char *Ip_string;

		fd = socket(AF_INET, SOCK_DGRAM, 0);

		/* I want to get an IPv4 IP address */
		ifr.ifr_addr.sa_family = AF_INET;

		/* I want IP address attached to "wlan0" */
		strncpy(ifr.ifr_name, "wlan0", IFNAMSIZ-1);

		ioctl(fd, SIOCGIFADDR, &ifr);

		close(fd);

		Ip_string = inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr);

		viewer.rootContext()->setContextProperty("ip_string", Ip_string);
	}

	
    viewer.setFlags(Qt::FramelessWindowHint);
    viewer.setColor(QColor(Qt::transparent));
    viewer.setMinimumSize(QSize(640, 360));
    viewer.show();

    signal (SIGINT, exit_properly);
    signal (SIGTERM, exit_properly);
    return app.exec();
}

void exit_properly (int sig)
{
	signal (SIGINT, SIG_DFL);
	p_app->exit();
}
